class Node:
    def __init__(self, data=None):
        self.val = data
        self.next = None

class LinkedList:
    pass 

if __name__ == '__main__': 
    l = LinkedList() 
    l.push(1) 
    l.push(2)
    l.push(3)

    print(l)

    l.reverse_list() 
    print(l)

