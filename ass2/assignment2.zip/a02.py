class Address: 
    pass 

class Employee: 
    pass 

class Lecturer(Employee): 
    pass 
    

if __name__ == "__main__": 
    # Uncomment these to test out your code before run.py local 

    
    # a = Address() 
    # a.house_no = 2 
    # a.street = 3 
    # a.city = "Peshawar"
    # a.country = "Pakistan"

    # print(a.get_full_address())
    # print(a)


    # e = Employee() 
    # e.set_current_address(1, 2, "Cape Town", "South Africa")
    # print(e.get_current_address()) 

    # e.set_permanent_address(4, 19, "Cape Town", "South Africa")
    # print(e.get_permanent_address())

    # print(e)

    # l = Lecturer() 
    # l.set_permanent_address(44, 24, "KL", "Malaysia")
    # print(l.get_permanent_address())
    # print(l)